import numpy as np
import cv2


point_list = [] # 마우스로 찍은 위치의 좌표값 넣을 배열


def mouse_callback(event, x, y, flags, param):
    global point_list, img_original


    # 마우스 왼쪽 버튼 누를 때마다 좌표를 리스트에 저장
    if event == cv2.EVENT_LBUTTONDOWN:
        print("(%d, %d)" % (x, y))
        point_list.append((x, y))

        print(point_list)
        # 이미지, 좌표, 반지름, 색, 테두리 두께
        cv2.circle(img_original, (x, y), 0, (0, 0, 0), 0)



cv2.namedWindow('original')
cv2.setMouseCallback('original', mouse_callback)

# 원본 이미지
img_original = cv2.imread('test3.jpg') # test3.jpg 파일을 img_original 변수에 저장

img_original[130:133,130:133] = [0,0,255] # 3x3 크기의 공간을 빨간색 픽셀값으로 변경
img_original[200:203,130:133] = [255,0,0] # 3x3 크기의 공간을 파랑색 픽셀값으로 변경
img_original[200:203,200:203] = [0,255,0] # 3x3 크기의 공간을 초록색 픽셀값으로 변경


while(True):

    cv2.imshow("original", img_original)


    height, weight = 306, 614 # return 되는 이미지의 크기 값


    if cv2.waitKey(1)&0xFF == 32: # spacebar를 누르면 루프 탈출.
        break


# 좌표 순서 - 상단왼쪽 끝, 상단오른쪽 끝, 하단왼쪽 끝, 하단오른쪽 끝
pts1 = np.float32([list(point_list[0]),list(point_list[1]),list(point_list[2]),list(point_list[3])])
pts2 = np.float32([[0,0],[weight,0],[0,height],[weight,height]])


print('pts1 : ',pts1)
print('pts2 : ',pts2)


M = cv2.getPerspectiveTransform(pts1,pts2)      # pts1의 좌표를 pts2의 좌표로 변환 시킬 변수 M 설정


img_result = cv2.warpPerspective(img_original, M, (weight,height))      # 이미지 와핑


r=0     # red볼을 둘 공간을 찾았을 때 조건문을 돌리지 않기 위한 변수
b=0     # blue볼을 둘 공간을 찾았을 때 조건문을 돌리지 않기 위한 변수
g=0     # green볼을 둘 공간을 찾았을 때 조건문을 돌리지 않기 위한 변수

for y in range(15,290):
    for x in range(15,600):
        if img_result[y,x][0] == 0 and img_result[y,x][1] == 0 and img_result[y,x][2] == 255 and r == 0:
            img_result = cv2.circle(img_result, (x,y),7,(0,0,255),-1)       # 해당 좌표값에 공 그리기
            r = r + 1
            print('<red>\ny, x :',y,', ',x)
        elif img_result[y,x][0] == 255 and img_result[y,x][1] == 0 and img_result[y,x][2] == 0 and g == 0:
            img_result = cv2.circle(img_result, (x,y),7,(255,0,0),-1)
            g = g + 1
            print('<green>\ny, x :',y,', ',x)
        elif img_result[y,x][0] == 0 and img_result[y,x][1] == 255 and img_result[y,x][2] == 0 and b == 0:
            img_result = cv2.circle(img_result, (x,y),7,(0,255,0),-1)
            b = b + 1
            print('<blue>\ny, x :',y,', ',x)

        if r == 1 and b == 1 and g == 1:
            k=1
            break
    if r == 1 and b == 1 and g == 1:
        break


print('\nok I know where they are')

cv2.imshow("result1", img_result)
cv2.waitKey(0)


